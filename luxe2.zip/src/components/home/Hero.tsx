

export default function HeroSection () {
    return(
        <div>
            <h2>Welcome to Interswitch Luxe store</h2>
        </div>
    )
}